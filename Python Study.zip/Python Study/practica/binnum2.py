class Binaries:
    arr=[1]
    ans=list()
    @classmethod
    def decBin(cls,n,bandera1):
        binNumber=0
        #Transformando n a entero
        n=int(n)
        #iterar hasta encontrar el valor maximo con el que se puede dividir el numero
        #si no encuentra agrega
        while True:
            i=max(cls.arr)
            if(n>max(cls.arr)):
                cls.arr.append(i*2)
            else:
                cls.arr.sort(reverse=True)
                print(cls.arr)
                break
        for j in cls.arr:
            binNumber=n//j
            cls.ans.append(binNumber)
            n=n%j
        cls.sigMa(bandera1,n,cls.ans)
    @classmethod
    def binDec(cls,n):
        myNum=0
        bin=[int(x) for x in str(n)]
        bin2=list()
        g=0
        bandera=False
        for g in range(len(bin)):
            
            if(bin[g]==1 or bandera==True):
                bandera=True
                bin2.append(bin[g])
        bin2.insert(0,0)
        for k in range(len(bin2)):
            i=max(cls.arr)
            cls.arr.append(i*2)
            cls.arr.sort()
        bin2.reverse()
        for y in range(len(bin2)):
            if(bin2[y] is 1):
                myNum=myNum+cls.arr[y]
        cls.ans.append(myNum)
    @classmethod
    def sigMa(cls,bandera1=True,n=0,binArr=list()):
        if(bandera1):
            if(n>=0):
                binArr.insert(0,0)
            else:
                binArr.insert(0,1)
    
        