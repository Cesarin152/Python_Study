#Modulo 4
from cuadrado import Cuadrado
from rectangulo import Rectangulo
from triangulo import Triangulo
from circulo import Circulo
cuadrado = Cuadrado(2,"Rojo")#Creacion del primer objeto
rectangulo=Rectangulo(2,4,"Azul")
triangulo=Triangulo(2,2,"Naranja")
circulo=Circulo(2,"Lila")
print("cuadrado",cuadrado)
print(cuadrado.area())
print("Rectangulo",rectangulo)
print(rectangulo.area())
print("Triangulo",triangulo)
print(triangulo.area())
print("Circulo",circulo)
print(circulo.area())




