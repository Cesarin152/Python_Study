import ascii_magic
output=ascii_magic.from_image_file('crust.jpg',columns=100,char='&')
print(len(output[:100]))
print(type(output))