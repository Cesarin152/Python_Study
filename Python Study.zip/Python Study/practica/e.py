def getE(pIteraciones):
    suma = 0.0
factorial = 1.0
for n in range(pIteraciones):
parcial = 0.0
n = n * 1.0
if n > 0:
factorial = factorial * n
parcial = 1.0 / factorial
suma = suma + parcial
return suma