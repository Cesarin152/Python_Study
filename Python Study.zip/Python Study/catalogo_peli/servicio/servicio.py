class CPeliculas:
    ruta_archivo="peli.txt"
    @staticmethod
    def agregar_peliculas(Pelicula):
        try:
            archivo=open(CPeliculas.ruta_archivo,"a")
            archivo.write(Pelicula+"\n")
        except Exception:
            print("Ocurrio un error",Exception)
        finally:
            archivo.close()
    @staticmethod
    def listar_peli():
        listado_pelicula=None
        try:
            archivo=open(CPeliculas.ruta_archivo,"r")
            lis=archivo.read()
            listado_pelicula=lis
        except Exception:
            print(Exception)
        finally:
            archivo.close()
        return listado_pelicula