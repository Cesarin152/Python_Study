from multiprocessing import Pool

def cubo(n):
    n+=1
    resultado =n**3
    return resultado


if __name__ == '__main__':
    print(Pool().map(cubo,[2,3,5]))#Hace 3 procesos a la vez con los valores de la lista
"""
from multiprocessing import Pool

def f(x):
    return x*x

if __name__ == '__main__':
    with Pool(5) as p:
        print(p.map(f, [1, 2, 3]))"""