cadena="Martin"
print("Mi grupo fav es: "+cadena)
numero1="1"
numero2="2"
print("Concatenacion: "+numero1+numero2)
#concatena
num1=1
num2=2
print("Operacion suma: ",num1+num2)
print("Operacion suma: "+ str(num1+num2))
#suma de numero "Cualquiera de 2 sirven"