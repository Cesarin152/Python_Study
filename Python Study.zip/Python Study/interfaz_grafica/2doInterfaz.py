from tkinter import *

raiz=Tk()

miFrame=Frame(raiz,width=500,height=400)
miFrame.pack()

miImagen=PhotoImage(file="comi.gif")

#Label(miFrame,text="Hola Profesor",fg="blue",font=("Comic Sans MS",18)).place(x=100,y=200)
Label(miFrame,image=miImagen ).place(x=100, y=200)

raiz.mainloop()
