import readline
 
readline.parse_and_bind("tab: complete")
 
def complete(text, state):
    """
        Remplaza cualquier cosa escrita, ya sea una letra o una palabra por la
        palabra "Éxito!" al presionar la tecla TAB
    """
    results = ["Éxito!", None] # Lista de posibilidades
    
    return results[state]

# Se cambia la función de completar por la propia
readline.set_completer(complete)

entrada =input('rctorr> ')

print(entrada)