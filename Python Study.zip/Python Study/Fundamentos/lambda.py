
#lambda p1, p2: expresion

#ayuda  acortar mas el codigo
adder = lambda x, y: x + y
print (adder (1, 2))
def add(num1 ,num2):
    num3 = num1+num2
    return num3
print(add(1,2))



def trigonometricas():