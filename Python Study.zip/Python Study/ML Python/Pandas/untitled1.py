# -*- coding: utf-8 -*-
"""
Created on Wed Jan 26 18:33:36 2022

@author: cesar
"""

import numpy as np
import pandas as pd

data=np.array([['','col1','col2'],['Fila1',11,22],['Fila2',33,44]])
#Creando data frame
dataF=pd.DataFrame(data=data[1:,1:],index=data[1:,0],columns=data[0,1:])
print(dataF)
#Creando otro data Frame
df=pd.DataFrame(np.array([[1,2,3],[4,5,6],[7,8,9]]))
print('DataFrame:')
print(df)
#Creando Series
series=pd.Series({'Argentina':'Buenos Aires',
                  'Chile':'Santiago',
                  'Colombia':'Bogota',
                  'Peru':'Lima'})
print('Series')
print(series[0:3])
print()
#Forma del Df
print('Forma DF')
print(df.shape)
#Altura del Df
print('Altura del Df')
print(len(df.index))
print()
#Estadistica del Df
print('Estadisticas del Df:')
print(df.describe())
print()
#Media de las columnas Df
print('Media de las columnas Df:')
print(df.mean())
print()
#Correlacion de las columnas df
print('Correlacion del Df:')
print(df.corr())
print()
#Cuenta los datos del Df 'No Nulos'
print('Conteo de datos del Df:')
print(df.count())
print()
#Valor mas alto de cada columna del Df
print('Valor mas alto de la columna del Df:')
print(df.max())
print()
#Valor minimo de cada columna del Df
print('Valor minimo de la columna del df')
print(df.min())
print()
#Mediana de cada columna del Df
print('Mediana de la columna del Df')
print(df.median())
print()
#Desviacion estandar de cada columna del Df
print('Desviacion estandar de la columna del Df')
print(df.std())
print()



