class Persona:
    def __init__(self, nombre, edad):
        self.__nombre = nombre
        self.__edad = edad
    def get_nombre(self):
        return self.__nombre
    def set_nombre(self,nombre):
        self.__nombre=nombre
    def get_edad(self):
        return self.__edad
    def set_edad(self,edad):
        self.__edad=edad
    def __str__(self):
        return "Nombre:" + self.__nombre + ",edad:"+str(self.__edad)


class Empleado(Persona):
    def __init__(self, nombre, edad, sueldo):
        super().__init__(nombre, edad)
        self.__sueldo = sueldo
    def get_sueldo(self):
        return self.__sueldo
    def set_sueldo(self,sueldo):
        self.__sueldo=sueldo
    def __str__(self):
        return super().__str__()+",sueldo:" + str(self.__sueldo)

n=input("Ingrese el Nombre : ")
edad=int(input("Ingrese la Edad: "))
persona = Persona(n,edad)
print(persona)
n = input("Ingrese el Nombre: ")
edad = int(input("Ingrese la Edad: "))
sueldo=int(input("Ingrese el sueldo: "))
empleado = Empleado(n,edad, sueldo)
print(empleado)

#Modificando Valores
n = input("Ingrese el Nombre: ")
sueldo = int(input("Ingrese el sueldo: "))
empleado.set_nombre(n)
empleado.set_sueldo(sueldo)
print(empleado)

persona.set_nombre("Cesar")
persona.set_edad(18)
print(persona)
