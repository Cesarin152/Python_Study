#Parametro es una variable definida entre los parentesis de una funcion
#Argumento(arg)es el valor enviado a la funcion

def funcion_arg(nombre,apellido):
    total=nombre+ apellido
    return total
print(funcion_arg("Kaheng"," Quijada"))

def func_ed(mis,nalgas):
    jose=mis+nalgas
    return jose

print(func_ed("come"," comida"))
