import math as m

class voltajes_ll_ln(object):
    def __init__(self,vln,vll) -> None:
        self.voltaje_ll=vll
        self.voltaje_ln=vln
    def vll_to_vln(self,a):
        pass
    def vll_to_vll(self,b):
        vag=m.degrees(120)
        vbg,vcg=vag
        vlls=[vag,vbg,vcg]
        


    def vln_to_vll(self,c):
        pass
    def vln_to_vll(self,d):
        pass

