list=[5,6,3,9,2,12,3,8,7]
x=0
for i in list:
    
    if i==12:
        list[len(list)-1],list[x]=list[x],list[len(list)-1]
        break
    x=x+1
print(list)