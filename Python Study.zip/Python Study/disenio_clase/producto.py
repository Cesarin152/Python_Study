class Producto:
    contador_pruducto=0#Variable de clase
    
    def __init__(self,nombre,precio):
        Producto.contador_pruducto =Producto.contador_pruducto + 1
        self.__id_producto=Producto.contador_pruducto
        self.__nombre=nombre
        self.__precio=precio
    @property
    def precio(self):
        return self.__precio
    def __str__(self):
        return "ID: "+str(self.__id_producto)+" nombre: "+self.__nombre+" Precio: "+str(self.precio)


producto1=Producto("Camisa",10)
print(producto1)
producto2=Producto("Chancleta",20)
print(producto2)