#Importar Libreria de matriz
import numpy
#Matrices Rellenas de 0 a,b
def entrada():
    n=int(input('Proporciona el tamaño de la matriz n*n: '))#Pido al usuario el tamanio de la matriz
    a=list(numpy.zeros((n,n)))#rellenar la matriz a con 0 de dimensiones nxn donde n es el valor proporcionado por el usuario
    b=list(numpy.zeros((n,1)))#rellenar el vector b con 0 de dimensiones nx1 ''''''''''
    #Datos de entrada la matriz a y el vector b
    #Datos  de entrada de la Matriz a
    for j in range(3):
        for l in range(3):
            a[j][l]=float(input())
    #Datos de entrada del vector b
    for j in range(3):
        for l in range(1):
            b[j][l]=float(input())
    #Imprimir datos de la matriz y vector
    #Impresion de la matriz a
    for j in range(3):
        for l in range(1):
            print(b[j][l],end='|')
            if l==0:
                print('\n')
    #impresion del vector b
    for j in range(3):
        for l in range(3):
            print(a[j][l],end='|')
            if l==2:
                print('\n')
    return a,b,n
def gauss_simple(a,b,n):
    #Gaus Simple Procedimiento eliminacion hacia adelante
    for k in range(n-1):
        for i in range(k+1,n):
            factor=a[i][k]/a[k][k]#Asigandole valores a factor de acuerdo al pivoteo de la diagonal principal
            for j in range(k,n):
            #Operaciones con filas de acuerdo el pivote o factor
                a[i][j]=a[i][j]-factor*a[k][j]
            b[i]=b[i]-factor*b[k]
    return a,b
def sustitucion_atras(a,b,n):
    #Sustitucion hacia atras
    x=list(numpy.zeros((n,1)))
    #asignar el valor de x3
    x[n-1]=b[n-1]/a[n-1][n-1]
    #Despejando incognitas 'Encontrar x1,x2,xn...'
    for i in range(n-2,-1,-1):
        sum=0
        for j in range(i+1,n):
            sum=sum+a[i][j]*x[j]
        x[i]=(b[i]-sum)/a[i][i]
    return x


if __name__ =='__main__':
    (A,B,N)=entrada()
    (A,B)=gauss_simple(A,B,N)
    #Imprimir Matriz a
    print(A)
    #Imprimir Vector b     
    print(B)
    print(sustitucion_atras(A,B,N))
    
        
