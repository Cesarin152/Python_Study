import pandas as pd
class Econstantes:
    df=pd.read_csv("prueba.csv") 
    limites=[]
    tablas_datos=list(df["datos"])
    frecuencia_relativa=[]
    frecuencia_valor_clase=[]
    puente=None
    
    #graficar=chart(Estadistica.valores_limite,Estadistica.tablas_datos,self.puente,Estadistica.frecValor_clase,Estadistica.frecRelativa)