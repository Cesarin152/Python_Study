import re

nombre1='Sandra Lopez'
nombre2='Antonio Gomez'
nombre3='sandra Lopez'
nombre4='Jara Trujillo'
nombre5='Lara Solis'
cadena1='534523'
cadena2='a34434'


#match:Buscar si hay coincidendicia en un patron de busqueda al comienzo de una cadena de texto
if re.match('Sandra',nombre3,re.IGNORECASE):
    print('Hemos encontrado el nombre')
else:
    print('No se ha encontrado')

if re.match('.ara',nombre5,re.IGNORECASE):
    print('Hemos encontrado el nombre')
else:
    print('No se ha encontrado')

if re.match('\d',cadena1):
    print('Hemos encontrado el numero')
else:
    print('No se ha encontrado')