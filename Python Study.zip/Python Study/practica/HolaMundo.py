from matplotlib import pyplot as plt

plt.scatter([1,2,3,4,5],[1,2,3,4,5])
plt.show()
