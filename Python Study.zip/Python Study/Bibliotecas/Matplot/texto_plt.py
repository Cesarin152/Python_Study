import matplotlib.pyplot as plt

plt.text(0.55, 0.55, 'Hello World!', fontsize=20, color='green')
plt.show()