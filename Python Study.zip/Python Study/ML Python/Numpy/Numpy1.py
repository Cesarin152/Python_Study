import numpy as np
array=np.array([[1,2,3,4],[5,6,7,8]],dtype=np.int64)
print(array)
print()
a=np.array([1,2,3])
print('1D Arr:')
print(a)
print()

b=np.array([(1,2,3),(4,5,6)])
print('2D Arr:')
print(b)
print(b[0][0])
import sys

S=range(1000)
print('Resultado Lista de Python:')
print(sys.getsizeof(5)*len(S))
print()
D=np.arange(1000)
print('Resultado NumPy Array:')
print(D.size*D.itemsize)