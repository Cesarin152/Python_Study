import psycopg2 as db

conexion=db.connect(
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432",
    database="test_db"
)
try:
    with conexion:
        #Cursos es un objeto que nos va a permitir ejecutar secuencia SQL en pg
        with conexion.cursor() as cursor:
            #sentencia="SELECT * FROM persona WHERE id_persona=1"
            sentencia='SELECT * FROM persona WHERE id_persona=%s'#placeholder
            #id_persona=2
            id_persona=tuple(input("Proporciona la pk a buscar: "))
            #llave_primaria=(id_persona,)
            cursor.execute(sentencia,id_persona)
            registros=cursor.fetchone()
            print(registros)
except Exception as e:
    print(f'Ocurrio un error;{e}')
finally:
    conexion.close()  