#Programa que declare una lista y la vaya llenando de números hasta que introduzcamos un número negativo. 
#Entonces se debe imprimir el vector (sólo los elementos introducidos).y luego tranformarlo a tupla

lista=[]
while True:
    x=int(input("ingrese un numero por pantalla: "))#variable.append()
    if x<0:
        break
    else:
        lista.append(x)
lista2=tuple(lista)
print(lista2)
