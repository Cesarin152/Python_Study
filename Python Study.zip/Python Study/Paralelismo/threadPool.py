import time
import logging 

from concurrent.futures import ThreadPoolExecutor

logging.basicConfig(level=logging.DEBUG,format="%(threadName)s: %(message)s")

def super_task(a,b):
    time.sleep(1)
    logging.info("Terminamos la tarea compleja !!!\n")
def suma(a,b):
    logging.info("suma"+str(a+b))

if __name__ == '__main__':
    with ThreadPoolExecutor(max_workers=2) as executor:
        executor.submit(super_task,1,2)
        executor.submit(super_task,3,4)
        executor.submit(super_task,5,6)
        executor.submit(suma,10,50)




    """executor=ThreadPoolExecutor(max_workers=2)
    executor.submit(super_task,1,2)
    executor.submit(super_task,3,4)
    executor.submit(super_task,5,6)
    executor.submit(suma,10,50)"""
    