# archivo = open('c:\\Cursos\\Python\\Archivos\\Leccion01\\prueba.txt', 'r', encoding='utf8')
archivo = open(r'C:\Users\Cesar\OneDrive\Programacion\pythondoc\Archivos\01-03-00-LeerArchivos-UP\prueba.txt', 'r', encoding='utf8')
# print(archivo.read())

# leer algunos caracteres
# print(archivo.read(5))
# print(archivo.read(3))

# leer lineas completas
print(archivo.readline())
print(archivo.readline())
