nombres=[]
n=[]

l=None
f=0
while True:
    
    print("Ingrese el nombre #",f+1)
    l=input(": ")
    if l=="x" or l=="X":
        break
    else:
        nombres.append(l)
        f=f+1

if f<=len(nombres):
    for x in range(len(nombres)):
        n.append(nombres[(x+1)*-1])
print(n)
print("entonc q e lo que ")

