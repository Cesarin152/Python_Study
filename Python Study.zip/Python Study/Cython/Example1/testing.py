import timeit

cy=timeit.timeit("example_cy.test(1000)",setup="import example_cy",number=100)
py=timeit.timeit("example.test(1000)",setup="import example",number=100)
print(cy,py)
print("Cython is {}x faster".format(py/cy))
#Ejecutar codigo desde consola python testing.py