class Persona:
    def __init__(self,nombre):
        self.__nombre=nombre#Atributo Privado
        self.__edad= 18
    @property   #es lo mismo que poner get_nombre en def
    def nombre(self):
        return self.__nombre
    @nombre.setter  #es lo mismo que poner set_nombre en def
    def nombre(self,nombre):
        self.__nombre=nombre
    @property
    def edad(self):
        return self.__edad
    @edad.setter
    def edad(self,edad):
        self.__edad=edad

p1=Persona("Juan")
#print(p1.__nombre)
#p1.nombre="Karla"
#print(p1.__nombre)
print(p1.nombre)
print(p1.edad)
p1.nombre="Karla"
p1.edad=20
print(p1.nombre)
print(p1.edad)
