import re

cadena='Vamos a aprender expresiones regulares en Python. Python es un lenguaje de sintaxis sencilla'
#Buscar una palabra en la cadena
textoBuscar='aprender'
textoEncontrado=re.search(textoBuscar,cadena)
print(textoEncontrado.start())
print(textoEncontrado.end())
print(textoEncontrado.span())
print(cadena[8:16])
textoBuscar2='Python'
#agregara en una lista el texto a buscar, la cual si se repite aparecera repetida en la lista
print(re.findall(textoBuscar2,cadena))
print(len(re.findall(textoBuscar2,cadena)))