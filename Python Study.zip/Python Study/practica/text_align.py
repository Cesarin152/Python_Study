import math
store=int(input())
string='H'
st='H'
st1='H'
st2='H'
num=(store*2)-1
for i in range(store):
    print(st.center(((store-1)*2)+1," "))
    st+=string*2
for i in range(store+1):
    st1=string*store
    st1=st1.rjust((store//2)+store,' ')
    print((st1.ljust((store//2)+store+(store*3),' ')),end='')
    st1=string*store
    print(st1)
for i in range(math.ceil(store/2)):
    st2=string*store*5
    print(st2.rjust((store*5)+(store//2),' '))
for i in range(store+1):
    st1=string*store
    st1=st1.rjust((store//2)+store,' ')
    print((st1.ljust((store//2)+store+(store*3),' ')),end='')
    st1=string*store
    print(st1)
for i in range(store):
    st=string*num
    st=st.rjust(store*4+((store*2)-i-1)," ")
    print(st.ljust(store*4+((store*2)-i)+i," "))
    num=num-2
    

