import textwrap

def wrap(string, max_width):
    strings=[string[i:i+max_width]for i in range(0,len(string)-1,max_width)]
    strings='\n'.join(strings)
    return strings

if __name__ == '__main__':
    string, max_width = input(), int(input())
    result = wrap(string, max_width)
    print(result)