class Shrubbery:
    def __init__(self, w, h):
        self.width = w
        self.height = h
        self.describe()

    def describe(self):
        print("This shrubbery is", self.width,"bys", self.height, "cubits.")

