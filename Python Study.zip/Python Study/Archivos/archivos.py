l=["1","2","3"]
try:
    archivo=open("prueba.txt","w")#w=write r=read a=append w+=lectura y escritura r+=lectura y escritura
    for i in l:
        archivo.write(str(i)+"\n")
except Exception:
    print(Exception)
finally:
    archivo.close()