#a=int(input("Ingrese Valor "))
a=3
valorMinimo=0
ValorMaximo=5
dentroRango=(a>=valorMinimo) and (a<=ValorMaximo) 
#print(dentroRango)
if(dentroRango):
    print("Dentro de rango")
else:
    print("Fuera de rango")
    
vacacion=True
diaDescanso=False 
if( vacacion or diaDescanso):
    print("podemos ir al parque")
else:
    print("Tienes deberes")

""" 
if(not(vacaciones or DiaDescanso)):
    print("tienes deberes")
else:
    print("Puedes ir al parque")"""