# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 18:08:36 2022

@author: cesar
"""
import numpy as np
#Creacion de matrices 'Vacias'
unos=np.ones((3,4))
print(unos)
print()
ceros=np.zeros((3,4))
print(ceros)
print()
aleatorios=np.random.random((2,2))
print(aleatorios)
print()
vacia=np.empty((3,2))
print(vacia)
print()
full=np.full((2,2),8)
print(full)
print()
#Matriz que comience en 0 y pasos de 5 hasta 30
espacio1=np.arange(0,30,5)
print(espacio1)
print()
#Matriz con 5 valores entre 0 y 2
espacio2=np.linspace(0,2,5)
print(espacio2)
print()
identidad1=np.eye(4,4)
print(identidad1)
print()
identidad2=np.identity(4)
print(identidad2)
