import timeit
import class_c
import class_p
    
py = timeit.timeit("Shrubbery(20,4)", "from class_p import Shrubbery", number=100)
cy = timeit.timeit("Shrubbery(20,4)", "from class_c import Shrubbery", number=100)
#cy = timeit.timeit("from fibonacci_cython import fibonacci", number=30)
print(cy,py)
print("Cython is {}x faster".format(py/cy))
#print(cy)
