num1=int(input("Ingrese el numero 1 "))
num2=int(input("Ingrese el numero 2 "))
if(num1>num2):
    print("El mayor es num1")
else:
    print("El mayor es num2")