for letra in "Hola":
    print(letra)
i=10


