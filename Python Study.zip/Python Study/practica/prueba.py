import numpy as np
array=[6,3,1]
nodes=5
arr=list(np.zeros(10))
for i in range(len(arr)):
    arr[i]=0
for i in range(len(array)):
    arr[array[i]-1]=array[i]
print(arr)