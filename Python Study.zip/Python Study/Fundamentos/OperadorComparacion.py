a=4
b=2
resultado= (a==b)
print(resultado)
resultado=a!=b
print(resultado)
resultado=a>b
print(resultado)
resultado= a>=b
print(resultado)
resultado=a<b
print(resultado)
resultado=a<=b
print(resultado)

if a%2 == 0:
    print("Es un numero par")
else:
    print("Es numero impar")
    
edadLimite=18
edadPersona=17
if(edadPersona>=edadLimite):
    print("Adulto")
else:
    print("menor")