from modulo1 import Multiplicacion
multi=Multiplicacion(2,3)
resultado=multi.multiplicacion()
print(resultado)