class Rectangulo:
    def __init__(self,base,altura):
        self.base=base
        self.altura=altura
    def area(self):
        return self.base * self.altura
a=int(input("Ingrese la altura "))
b=int(input("Ingrese la base "))
Area=Rectangulo(b,a)
print("El total del area es: ",Area.area())
Area2=Rectangulo(4,2)
print(Area2.area())   
