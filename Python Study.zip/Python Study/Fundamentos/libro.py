x=input("Ingrese el titulo ")
y=input("Ingrese el autor ")
print(x,"fue escrito por",y)