import matplotlib
r=int(input("ingrese l numero de rectangulos "))
a=float(input("Ingrese el primer intervalo "))
b=float(input("Ingrese el segundo intervalo "))
t=float(input("Ingrese la formula "))
t1=None
for i in range(r):
    print("Ingrese el el valor del rectangulo",i+1," : ")
    x=float(input("Inserte valor"))
    t1=float(t)
    t1+=float(t)
total=t1*((b-a)/r)
print(total)
