import re

lista_nombres=['Ana Gomez',
                'Maria Martin',
                'Sandra Lopez',
                'Santiago Martin',
                'Sandra Sandoval']
for elemento in lista_nombres:
#^ metacaracter buscara en la lista los elementos que comiencen con alguna palabra deseado 
    if re.findall('^Sandra',elemento):#buscar todo los elementos que empiecen con sandra
        print(elemento)
for elemento in lista_nombres:
#$ metacaracter buscara en la lista los elementos que finalicen con alguna palabra deseado 
    if re.findall('Martin$',elemento):#buscar todo los elementos que finalicen con Martin
        print(elemento)
lista_enlances=['https://www.youtube.com',
                'https://www.facebook.com',
                'ftp://pildorasinformatica.es']
for dominios in lista_enlances:
    if re.findall('es$',dominios):
        print(dominios)
for dominios in lista_enlances:
    if re.findall('^https',dominios):
        print(dominios)
#clase de caracteres [sfg]buscara en el texto patrones con dichas letras sfg no importa el orden
lista_enlace2=['https://informaticaespaña.es',
                'https://informatica.es',
                'https://deepl.com']
for dominios in lista_enlace2:
    if re.findall('[ñ]',dominios):
        print(dominios)
lista_genero=['hombres',
            'Mujeres',
            'niños',
            'niñas']
for genero in lista_genero:
    if re.findall('niñ[oa]s',genero):
        print(genero)