
import sys
from PyQt5.QtWidgets import QApplication, QWidget

app = QApplication(sys.argv)

w = QWidget()
w.resize(400, 200)
w.setWindowTitle("Hello, World!")
w.show()

sys.exit(app.exec_())
