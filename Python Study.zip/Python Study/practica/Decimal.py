def print_formatted(number):
    octal(number)

def octal(number):
    
    mod=number
    oct=list()
    octn=''
    while True:
        mod=number%8
        number=number//8
        oct.append(str(mod))
        if number ==0:
            break

    oct.reverse()
    octn=''.join(oct)
    print(octn)


if __name__ == '__main__':
    n = int(input())
    print_formatted(n)