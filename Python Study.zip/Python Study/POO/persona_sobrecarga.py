class Persona:
    def __init__(self,nombre,edad):
        self.__nombre=nombre
        self.__edad=edad
    #metodo escrito sobre la clase padre
    def __add__(self,otro):#Binary
        return self.__nombre + otro.__nombre
    def __sub__(self,otro):
        return "Operacion no soportada"
    def __eq__(self,otro):
        return self.__edad == otro.__edad
    def __lt__(self,otro):
        return self.__edad < otro.__edad
p1=Persona("Juan ",19)
p2=Persona("Karla",20)
#p3=Persona("Cesar")
#Una nuevaforma de trabajar al operador de suma "+"
print(p1+p2)
print(p1-p2)
print(p1==p2)
print(p1<p2)