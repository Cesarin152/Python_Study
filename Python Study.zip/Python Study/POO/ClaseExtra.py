class Persona:
    def __init__(this,n,e,*v,**d):
        this.nombre = n
        this.edad = e
        this.valores=v
        this.diccionario=d
    def desplegar (this):
        print("Nombre:",this.nombre)
        print("Edad:",this.edad)
        print("Valores(Tupla):",this.valores)
        print("Diccionario: ",this.diccionario)
#Creando Objeto 1
p1=Persona("Juan",28)
p1.desplegar()
print("---------")
#Creando Objeto 2
p2 = Persona("Karla",30,2,4,5)
p2.desplegar()
print("---------")
#Creando objeto 3
p3=Persona("Paola",33,4,9,m="Manzana",p="Pera",j="Jicama")
p3.desplegar()
