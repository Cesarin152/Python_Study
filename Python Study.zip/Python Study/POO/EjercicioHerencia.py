class Vehiculo:
    def __init__(self,color,ruedas):
        self.color=color
        self.ruedas=ruedas
    def __str__(self):
        return "Color es: "+self.color+" las ruedas : "+str(self.ruedas)
class Coche(Vehiculo):
    def __init__(self, color, ruedas,velocidad):
        super().__init__(color, ruedas)
        self.velocidad=velocidad
    def __str__(self):
        return super().__str__()+" las velocidad: "+str(self.velocidad)
class Bicicleta(Vehiculo):
    def __init__(self, color, ruedas,tipo):
        super().__init__(color, ruedas)
        self.tipo=tipo
    def __str__(self):
        return super().__str__()+" tipo: "+self.tipo

c=input("Ingrese el color : ")
r=int(input("Ingrese las ruedas : ")) 
vehiculo=Vehiculo(c,r)
print(vehiculo)

c = input("Ingrese el color: ")
r = int(input("Ingrese las ruedas: "))
v=int(input("Ingrese la velocidad: "))
coche=Coche(c,r,v)
print(coche)

c = input("Ingrese el color: ")
r = int(input("Ingrese las ruedas: "))
t= input("Ingrese el tipo : ")
bicicleta=Bicicleta(c,r,t)
print(bicicleta)
