import readline
readline.parse_and_bind("tab: complete")
entrada=input("")