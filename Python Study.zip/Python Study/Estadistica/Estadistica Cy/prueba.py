import estadistica 
from estadistica_cy import Estadistica
import time
x=time.time
e=Estadistica(0,0,0)