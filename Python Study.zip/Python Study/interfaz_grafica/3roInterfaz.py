from tkinter import *
i=0
raiz=Tk()

miFrame=Frame(raiz, width=1200, height=600)
miFrame.pack()
#entry
cuadroTxt=Entry(miFrame)
cuadroTxt.grid(row=0, column=1, pady=2, padx=2)#ajustanto el cuadro de texto en una posicion
cuadroTxt.config(fg="red",justify="center",show="*")#Texto de color ,justificaccion,contraseña

cuadroTxt1 = Entry(miFrame)
cuadroTxt1.grid(row=1, column=1, pady=2,padx=2)

cuadroTxt2 = Entry(miFrame)
cuadroTxt2.grid(row=2, column=1, pady=2, padx=2)
#label
nombreLabel=Label(miFrame,text="Nombre:")
nombreLabel.grid(row=0, column=0, sticky="e", pady=2, padx=2)

apellidoLabel1 = Label(miFrame, text="Apellido:")
apellidoLabel1.grid(row=1, column=0, sticky="e", pady=2, padx=2)

direccionLabel2 = Label(miFrame, text="Direccion:")
direccionLabel2.grid(row=2, column=0, sticky="e", pady=2, padx=2)
for i in range(6):
    PruebaL = Label(miFrame, text=i+1)
    PruebaL.grid(row=i+3,column=0)

raiz.mainloop()
