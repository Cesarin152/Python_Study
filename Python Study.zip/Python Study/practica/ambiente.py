from itertools import product


x=product([1,3],[3])
print(tuple(x))