x=True
print(x)
y=False
print(y)
num1=3
num2=2
result=num1<num2
print(result)

if(num1<num2):
    print("El Valor num1 es menor que num2")
else:
    print("El valor Num1 No es menor que num2")