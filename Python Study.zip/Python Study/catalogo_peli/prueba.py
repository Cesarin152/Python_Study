from dominio.pelicula import Pelicula
from servicio.servicio import CPeliculas
import os
import time
while True:
    print("1. Agregar Peliculas")
    print("2. Lista Pelicula")
    print("3. Eliminar archivo de Pelicula")
    print("4. Salir ")
    menu=int(input("Ingrese un Valor "))
    print("\n\n")
    if menu==1:
        AddMovie=input("Ingrese el nombre de la pelicula ")
        pelicula=Pelicula(AddMovie)
        CPeliculas.agregar_peliculas(pelicula.__str__())
        time.sleep(3)
        print("\n\n")
    elif menu==2:
        print(CPeliculas.listar_peli())
        time.sleep(3)
        print("\n\n")
    elif menu==3:
        os.remove("C:\\Users\\cesar\\OneDrive\\Documentos\\catalogo_peli\\peli.txt")
        time.sleep(3)
        print("\n\n")
    elif menu==4:
        break
    else:
        print("ERROR ")