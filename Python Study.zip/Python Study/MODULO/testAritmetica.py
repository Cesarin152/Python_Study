import modulo1 as aritmetica

resultado=aritmetica.sumar(1,2)
print(resultado)

resultado=aritmetica.restar(3,1)
print(resultado)