import multiprocessing

def retirar(saldo, lock):
    for i in range(500):
        lock.acquire()
        saldo.value=saldo.value-1
        print("Retirar",saldo.value)
        lock.release()
    print("Fin del retiro")

def depositar(saldo, lock):
    for i in range(2000):
        lock.acquire()
        saldo.value=saldo.value + 1
        print("Depositar",saldo.value)
        lock.release()
    print("Fin del deposito")

def ejecutar_transacciones():
    saldo=multiprocessing.Value('i',1000)#Valor de argumentos Entero 10000
    lock=multiprocessing.Lock()#Funcion para bloquear demas procesos
    proceso_1=multiprocessing.Process(target=retirar,args=(saldo,lock))#Asignando el proceso 1
    proceso_2=multiprocessing.Process(target=depositar,args=(saldo,lock))#Asignando el proceso 2

    proceso_1.start()#Iniciar invocacion
    proceso_2.start()

    proceso_1.join()#Esperar que finalice la ejecucion de la funcion proceso_1
    proceso_2.join()
    print('Saldo final: %i' %saldo.value)

if __name__ == "__main__":
    """for i in range(10):#Ejecutar simulacion para 10 iteraciones
        ejecutar_transacciones()"""
    ejecutar_transacciones()

