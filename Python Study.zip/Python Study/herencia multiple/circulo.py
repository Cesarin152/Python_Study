import math as m
from figura_geometrica import FiguraGeometrica
from color import Color
class Circulo(FiguraGeometrica,Color):
    def __init__(self,radio,color):
        FiguraGeometrica.__init__(self,radio,radio)
        Color.__init__(self,color)
    def area(self):
        return str(m.pi*self.ancho*self.alto)
    def __str__(self):
        return super().__str__()+" Color: "+ Color.__str__(self)+" Area total:"
