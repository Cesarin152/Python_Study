import matplotlib.pyplot as plt

plt.text(5, 5, "Hello World!",
        fontsize=20,
        color="red",
        verticalalignment='top',
        horizontalalignment='center',
        bbox={'facecolor': 'grey','pad': 10}
        )

plt.xlim([0, 10])
plt.ylim([0, 10])
plt.show()
