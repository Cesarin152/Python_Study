import re
def replace(rep):
    if '&&' in str(rep) :
        return ' and '
    elif '||' in str(rep):
        return ' or '
    

text="""
11
a = 1;
b = input();

if a + b > 0 && a - b < 0:
    start()
elif a*b > 10 || a/b < 1:
    stop()
print set(list(a)) | set(list(b))
#Note do not change &&& or ||| or & or |
#Only change those '&&' which have space on both sides.
#Only change those '|| which have space on both sides.
"""

n=re.sub(r"(\&\&|\|\||11)",replace,text,3)
#n=re.sub(r"\d[0-100]",replace,text)
print(n,end='')
#output
#if  and is the || of string