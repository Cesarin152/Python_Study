class MiClase:
    variable_clase="Variable CLASE"
    def __init__(self):
        self.variable_instancia="Variable Instancia"
    @staticmethod#No recibe parametro ,se asocia a la clase no a los objetos; "Self" no disponible porque se asocia con objetos
    def metodo_estatico():
        print("Método estatico")
        print(MiClase.variable_clase)#Se accede desde la clase "MiClase"porque no hay un parametro self
        #Desde un metodo estatico no podemos acceder a una variable de instancia
        #print(MiClase.variable_instancia)
    @classmethod#otra forma; diferencia recibe un parametro que es tipo de la clase,no recibe self porque se asocia con objetos
    def metodo_clase(cls,w):
        print("Metodo Clase: "+str(cls)+w)
        print(cls.variable_clase)
        #No podemos acceder a la variable de instancia desde contexto estatico
        #print(cls.variable_instancia)
    def metodo_instancia(self):
        self.metodo_estatico()
        self.metodo_clase()
        print("Accediendo variable clase: "+ self.variable_clase) 
        print("Accediendo variable instancia: "+self.variable_instancia)
#MiClase.metodo_estatico()
MiClase.metodo_clase("HOLA") 
print()
objeto1= MiClase()#Creo el objeto
objeto1.metodo_instancia()
#El contexto estatica no puede acceder al contexto dinamica "objetos" 
#El contexto dinamico si puede acceder al estatico


