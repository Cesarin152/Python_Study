from time import sleep
import os
import pandas as pd
from constantes import Econstantes
class Estadistica:
    dato_default = 30
    puente_default = 0.20
    clase_default = 8
    valores_limite = []
    tablas_datos =Econstantes.tablas_datos
    frecRelativa=[]
    frecValor_clase=[]
    n=0
    m=0
    def __init__(self, datos, mayor, menor):
        self.datos = datos
        self.dato_mayor = mayor
        self.dato_menor = menor
        self.tabla_valor()
    def calculo(self):
        # Calcular la clase
        self.clase_necesaria = (self.datos*Estadistica.clase_default)/Estadistica.dato_default
        # Resta del dato mayor - el menor
        x = self.dato_mayor-self.dato_menor
        # Redondear a Entero
        self.clase_necesaria = round(self.clase_necesaria)
        # Resultado de la resta del Dm+ - Dm- entre la cantidad de datos
        self.perdida_dato = x/self.datos
        # Redondear el resultado a 2 decimales
        self.limites = self.dato_menor-self.perdida_dato
        self.limites = round(self.limites, 2)
        print("Primer Limite ",self.limites)
        self.puente = (Estadistica.puente_default*self.datos) /Estadistica.dato_default
        print("Primer Numero puente ",self.puente)
        self.primer_dato = self.limites
        self.correccion()
    

    def correccion(self):
        for i in range(self.clase_necesaria+1):
            Estadistica.valores_limite.append(self.limites)
            self.limites = self.limites+self.puente
        if (Estadistica.valores_limite[-1] < self.dato_mayor):
            print("Numero Puente Antiguo ",self.puente)
            Estadistica.valores_limite.clear()
            self.dato_mayorNuevo = self.dato_mayor+self.perdida_dato
            self.puente = round((self.dato_mayorNuevo -self.primer_dato)/self.clase_necesaria,2)
            self.limites = self.primer_dato
            print("Correcion ", self.puente)
            return self.correccion()
        else:
            Econstantes.limites=Estadistica.valores_limite
            Econstantes.puente=self.puente
            print("Nuevo Puente ",self.puente)
            self.frecuencia_clase()
    def tabla_valor(self):
        try:
            x=0
            while True:
                print("\n\n Si esta usando un archivo solo presione ENTER")
                print("Ingrese el valor ",x+1)
                self.data=input("Esperando valor: ")
                print("\n")
                if self.data !="":
                    if x==0:
                        Estadistica.tablas_datos.clear()
                        print(Estadistica.tablas_datos)
                    Estadistica.tablas_datos.append(float(self.data))
                else:
                    Estadistica.tablas_datos.sort()
                    Econstantes.tablas_datos=Estadistica.tablas_datos
                    self.datos=int(len(Estadistica.tablas_datos))
                    self.dato_mayor=Estadistica.tablas_datos[-1]
                    self.dato_menor=Estadistica.tablas_datos[0]
                    print(Estadistica.tablas_datos)
                    break
                x+=1
            
            self.calculo()
        except TypeError:
            print("Ha Ocurrido un error 01 ",TypeError)
            del self.data,Estadistica.tablas_datos,self.dato_mayor,self.dato_menor,self.datos
            sleep(5)
            exit(1)
    def frecuencia_clase(self):
        x=0
        bandera=0
        while True:
            #Iterar todo los datos de la tabla y buscar su frecuencia de clase
            tempClass=0
            for i in Estadistica.tablas_datos:
                if  i>Estadistica.valores_limite[x] and  i<Estadistica.valores_limite[x+1]:
                    tempClass+=1
                    bandera+=1
            Estadistica.frecValor_clase.append(tempClass)
            if bandera==(self.datos):
                del bandera,tempClass
                print(Estadistica.frecValor_clase)
                break
            x+=1;
        Econstantes.frecuencia_valor_clase=Estadistica.frecValor_clase
        self.frecuencia_relativa()
    def frecuencia_relativa(self):
        for i in Estadistica.frecValor_clase:
            Estadistica.frecRelativa.append(round(i/self.datos,3))
        Econstantes.frecuencia_relativa=Estadistica.frecRelativa
        self.bin()

    def bin(self):
        try:
            archivo=open("cache.txt","w")
            for i in range(self.clase_necesaria):
                archivo.write("Clase #"+str(i+1)+" "+str(round(Estadistica.valores_limite[i], 2))+"--"+str(round(Estadistica.valores_limite[i+1],2))+"   ||Frecuencia de clase:"+str(Estadistica.frecValor_clase[i])+"||"+"   Frecuencia Relativa:"+str(round(Estadistica.frecValor_clase[i]/self.datos,3))+"\n")
            Estadistica.n=int(sum(Estadistica.frecValor_clase))
            Estadistica.m=Estadistica.n/self.datos
        except Exception:
            print("Ha ocurrido un error 02", Exception)
        finally:
            archivo.close()
            print(self.__str__(),"\n")
    def __str__(self):
        with open("cache.txt","r") as c:
            temp=str(c.read())
            c.close()
            os.remove("cache.txt")
            temp=temp+"\n"+"\t"+"\t"+"\t"+"\t"+"n="+str(Estadistica.n)+"\t"+"\t"+"\t"+str(Estadistica.m)
            print(temp)
        return "Fin de la clase Estadistica"
        
        



