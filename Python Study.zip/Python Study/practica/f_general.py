import math as m

while True:
    try:
        a=float(input("Introduzca A: "))
        b=float(input("Introduzca B: "))
        c=float(input("Introduzca C: "))


        d=m.pow(b,2)-4*a*c

        if d<0:
            print("esta porqueria es imaginaria")
            break
        elif d==0:
            print("solo tiene una respuesta: ",-b/2*a)
            break
        else:
            f=((-b)+m.sqrt(d))/(2*a)
            e=((-b)-m.sqrt(d))/(2*a)
            print("Las respuesta son: ",f,",",e)
            break
        break
            
    except:
        print("Syntax error")
        continue
