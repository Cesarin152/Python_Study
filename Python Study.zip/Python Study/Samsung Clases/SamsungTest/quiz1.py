
for i in range(100,1000):
    numero=i
    unidad=int(i%10)
    decena=int((i/10)%10)
    centena=int(((i/10)/10)%10)
    if(i==((unidad**3)+(decena**3)+(centena**3))):
        print('Numero Armstrong:',i)

    





    