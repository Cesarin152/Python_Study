import timeit
import fibonacci_cython
import time

    
py = timeit.timeit("fibonacci(30)", "from fibonacci import fibonacci", number=30)
cy = timeit.timeit("fibonacci(30)", "from fibonacci_cython import fibonacci", number=30)
#cy = timeit.timeit("from fibonacci_cython import fibonacci", number=30)
#print(cy,py)
print("Cython is {}x faster".format(py/cy))
#print(cy)
