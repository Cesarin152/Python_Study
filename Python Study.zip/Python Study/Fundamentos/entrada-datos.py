resultado=input("Ingrese un valor: ")
print("El resultado es",resultado)
num1=int(input("Ingrese el numero que sera sumado: "))
num2=int(input("Ingrese el numero que sera sumado con el primero: "))
print("El resultado es:",num1+num2)
numero1=input("Ingrese un Valor 1 ")
numero2=input("Ingrese un valor 2 ")
print("El resultado concatenado: ",numero1+numero2)

