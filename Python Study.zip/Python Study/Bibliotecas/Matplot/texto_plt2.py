import matplotlib.pyplot as plt

plt.text(4,6, 'Hello World!', fontsize=20, color='green')
plt.xlim([0,10])#ajustar rangos ejes
plt.ylim([0,10])#Ajustar rangos

plt.show()