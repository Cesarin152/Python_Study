def Gseid(a,b,n,x,imax,es,lamb):
    for i in range(1,n):
        dummy=a[i][i]
        for j in range(1,n):
            a[i][j]=a[i][j]/dummy
        b[i]=b[i]/dummy
    for i in range(1,n):
        sum=b[i]
        for j in range(1,n):
            if i is not j:
                sum=sum-a[i][j]*x[j]
    x[i]=sum
    iter=1
    sentinel=1
    for i in range(1,n):
        old=x[i]
        sum=b[i]
        for j in range(1,n):
            if i is not j:
                sum=sum-a[i][j]*x[j]
        x[i]+lamb*sum+(1.-lamb)*old
        if (sentinel == 1) and (x[i] !=0):
            ea=abs((x[i]-x[i-1])/x[i])*100
            if ea> es:
                sentinel=0
    iter=iter+1
    if sentinel ==1 or (iter>=imax):
        exit(1)

        
