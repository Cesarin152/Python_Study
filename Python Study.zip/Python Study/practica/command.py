if __name__ == '__main__':
    N = int(input())
    arr=[]
    for i in range(N):
        command,*parameter=input().split()
        if command=='insert':
            i=int(parameter[-2])
            e=int(parameter[-1])
            arr.insert(i,e)
        elif command=='print':
            print(arr)
        elif command=='remove':
            arr.remove(int(parameter[0]))
        elif command=='append':
            arr.append(int(parameter[0]))
        elif command=='sort':
            arr.sort()
        elif command=='pop':
            arr.pop()
        elif command=='reverse':
            arr.reverse()
            
            