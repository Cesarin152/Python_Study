x="4"
y="5"
print(int(x+y))
v = int(x+y)
d=1
print(v+d)
