print("Proporcione los siguientes datos del libro: ")
nombre=input("Proporciona Nombre ")
id=int(input("Ingrese ID "))
precio=float(input("Ingrese Precio "))
envioGratis=input("Indica si el envio es Gratuito(True/False)")
if(envioGratis=="True"):
    envioGratis=True
elif envioGratis=="False":
    envioGratis=False
else:
    envioGratis="Valor Incorrecto"

print("Nombre:",nombre)
print("ID:",id)
print("Precio:",precio)
print("Envio Gratuito?:",envioGratis)
print(type(envioGratis))