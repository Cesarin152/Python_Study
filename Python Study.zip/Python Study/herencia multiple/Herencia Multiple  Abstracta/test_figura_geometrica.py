from cuadrados import Cuadrado
from figura_geometricas import FiguraGeometrica
from rectangulos import Rectangulo
#No es posible crear objetos de una clase abstracta
#figuraGeometrica=FiguraGeometrica()
cuadrado = Cuadrado(4, "rojo")
rectangulo=Rectangulo(2,5,"BLACK")
print(cuadrado.area())
print(cuadrado.color)
print(rectangulo.area())
print(rectangulo.color)
#el orden de busqueda es:
#Cuadrado, FiguraGeometrica(izquierda), Color(derecha), Object(Clase Abuela) 
print(Cuadrado.mro())
