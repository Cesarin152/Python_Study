x=10
print(type(x))
y=15.10
print(type(y))
z=None
print(type(z))