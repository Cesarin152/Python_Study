from _typeshed import NoneType


nombres=["Juan","Karla","Ricardo","Maria"]
print(nombres)
#Largo de nuestra lista
print(len(nombres))
#Acceder a un elemento 0
print(nombres[0])
print(nombres[1])
#navegacion inversa
print(nombres[-1])
print(nombres[-2]) 
#imprimir rango
print(nombres[0:2])#sin incluir indice 2
#imprimir los elementos de inicio hasta el indice proiporcionado
print(nombres[:3])#sin incluir el indice 3
#imprimir los elementos hasta el final desde el indice proporcionado
print(nombres[1:])
#cambia elementos de una lista
nombres[3]=None
print(nombres)
#iterar la lista
for nombre in nombres:
    print(nombre)
#revisar si existe un elemento en la lista
if "Carla" in nombres:
    print("Karla existe")
else:
    print("No existe")
#agregar un nuevo elemento
nombres.append("Lorenzo")
print(nombres)
#insertar un nuevo elemento en el indicie proporciconado
nombres.insert(1,"Octavio")
print(nombres)
#remover un elemento
nombres.remove("Octavio")
print(nombres)
#remover el ultimo elemento de nuestra lista
nombres.pop()
print(nombres)
#remover el indice indicado
del nombres[0]
print(nombres)
#limpiar todos los emlementos 
nombres.clear()
print(nombres)
#elimiar por completo la lista
del nombres
