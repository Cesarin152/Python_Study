#condition=False

#while condition:
#    print("Ejecutando While")
#else:
#    print("Fin Ciclo While")

i=0
while i<3:
    print(i)
    i+=1
else:
    print("Fin Ciclo")