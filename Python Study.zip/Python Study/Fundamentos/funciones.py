def mi_primerafuncion():
    x=5
    t=4#int o float
    y='Hola'#Char
    print("Hola Mundo")
    print(y)
    print(x)
    print(x+t)#Voy a transformarlo a cadena de caracteres con str 
mi_primerafuncion()

