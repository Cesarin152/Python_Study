class MiClase:
    variable_clase="Variable de clase"
    #variable_instancia=Modificando variable instancia
    def __init__(self,variable_instancia):
        self.variable_instancia=variable_instancia#Variable del ibjeto
        #variable_clase="Modificando Variable ClasE"
variable_normal=None
print("1 "+MiClase.variable_clase)#Accediendo variable Clase  .1
#print(MiClase.variable_instancia)#No es posible acceder debido a que no se inicio el constructor
objeto1=MiClase("Variable instanciA")#Aceddiendo al objeto     .2
#print("1.2 "+MiClase.variable_instancia)
MiClase.variable_instancia="Modificando variable instancia"#Otra forma de acceder.3 "Se convirtio en una variable clase"
print("2 "+objeto1.variable_instancia)#Solo asociado cuando modificamos el objeto1(valores distintos)
# Solo asociado cuando modificamos valor desde La Clase(valores distintos) y solo se puede acceder si hacemos el paso 3.
print("3 "+MiClase.variable_instancia)
#Podemos Acceder a las variables de clase desde los objetos
print("4 "+objeto1.variable_clase)
#Podemos Acceder a las vaariables con el nombre de la clase
print("5 "+MiClase.variable_clase)
#Modificando variable clase Dato solo se asocia con el objeto1
objeto1.variable_clase="Modificando Variable ClasE"#Accede a su propio valor porque es un objeto
print("6 "+objeto1.variable_clase)
print("7 "+MiClase.variable_clase)

objeto2=MiClase("Nuevo Valor  de variable instancia")
print(objeto2.variable_clase)
print("8 "+objeto2.variable_instancia)
objeto3=MiClase("Tercer Obejeto")
print("8.9 "+objeto3.variable_instancia)
MiClase.variable_clase="Cambio desde la clase"#Modificando valor de la clase
print("9.0 "+objeto1.variable_clase)#consulta el valor propio porque se modifico "Ver linea 19"
print("9.1 "+objeto2.variable_clase)
print("9.2 "+objeto3.variable_clase)
