import pandas as pd


class datos:
    df=pd.read_csv("database.csv",delimiter=";")
    Students=list(df["Estudiantes"])
    College_c=list(df["Carrera"])
    College_c2=list(df["Carrera2"])
    professor=list(df["Profesores"])
