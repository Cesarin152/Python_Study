# Math Calculations
#================================
from math import *
#================================
def fev(x):
  t=list()
  for i in x:
    for j in x:
      t.append(i+j)
  return t
fev([0,1,2,3,4,5,6])

