from modulo_persona import Persona
p1=Persona("Juan",28)
print(p1)