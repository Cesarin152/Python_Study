from orden import Orden
from producto import Producto

producto1 = Producto("Camisa", 100.00)
producto2 = Producto("Pantalon", 200.00)
producto3 = Producto("Calcetines", 50.00)
producto4 = Producto("Calzon", 40.00)
producto5 =Producto("Calzon", 40.00)

productos = [producto1, producto2]
productos2=[producto4,producto5]#prueba
orden1 = Orden(productos)
#ordenf=Orden(productos2)#prueba
print(orden1)
#print("orden f: ",ordenf)


orden2 = Orden(productos)
# productos.append(producto3)
orden2.agregar_producto(producto3)

print(orden2)
orden3 = Orden(productos)
orden3.agregar_producto(producto4)
print(orden3)
print(type(productos))
# for i in productos:
#    print(i)
orden3.total_producto()
print(orden3.total_producto())
#print(orden3.total_producto2)
