import numpy as np
e=[0,-1,-1,-1]
f=[2.04,2.04,2.04,2.04]
g=[-1,-1,-1,0]
r=[40.8,0.8,0.8,200.8]
def descomposicion(e,f,g,n):
    for k in range(1,n):
        e[k]=e[k]/f[k-1]
        f[k]=f[k]-(e[k]*g[k-1])
    print(e)
    print(f)
    return e,f
def sus_ad(n,r):
    for k in range(1,n):
        r[k]=r[k]-e[k]*r[k-1]
    print(r)
    return r
def sus_at(n,f,r,g):
    x=np.zeros((n,1))
    x[n-1]=r[n-1]/f[n-1]
    for k in range(n-2,-1,-1):
        x[k]=(r[k]-g[k]*x[k+1])/f[k]
    print(x)
    return x
n=4
e,f=descomposicion(e,f,g,n)
r=sus_ad(n,r)
x=sus_at(n,f,r,g)