import readline
 
readline.parse_and_bind("tab: complete")
 
def complete(text, state):
    """
        función llamada por readline para completar el texto escrito
    """
    # Lista de posibilidades
    posibilidades = ["arbol","avion", "balón", "bolsa", "calma", "calavera", "cereza", "vino"]
    
    # Encontramos las coincidencias
    results = [x for x in posibilidades if x.startswith(text)] + [None]
    
    return results[state]

# Se cambia la función de completar por la propia
readline.set_completer(complete)

entrada =input('')

print(entrada)