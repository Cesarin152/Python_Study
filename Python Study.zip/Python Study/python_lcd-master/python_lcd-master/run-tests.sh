#!/bin/bash

set -x
pytest -vv test_lcd.py
