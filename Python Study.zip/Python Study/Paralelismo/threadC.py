import threading
import time
def hola_mundo(nombre):
    print("Hola Mundo "+ nombre)
    time.sleep(5)
if __name__ == '__main__':
    thread=threading.Thread(target=hola_mundo,args=("Codi", ))
    thread.start()
    thread.join()#Le decimos al thread principal que se espera hasta que el thread 1 termine su ejecucion
    print("Hola Mundo desde el hilo principal\n")    