
'''
from distutils.core import setup
from Cython.Build import cythonize
setup(ext_modules=cythonize("example_cy.pyx"))
'''#Recibe como parametro el nombre del archivo .pyx
#Comando para compilar desde consola
#python setup.py build_ext --inplace
from distutils.core import setup
from distutils.extension import Extension
from Cython.Build import cythonize
ucrt_include = r'C:\Program Files(x86)\Windows Kits\10\Include\10.0.10240.0\ucrt'
ucrt_lib = r'C:\Program Files(x86)\Windows Kits\10\Lib\10.0.10240.0\ucrt\x64'
ext = Extension("class_c", ["class_c.pyx"],
                include_dirs=[ucrt_include], library_dirs=[ucrt_lib])
setup(
  name = 'cythonetest',
  ext_modules = cythonize([ext])
)