xi=2
x=[1,4,6,5,3,1.5,2.5,3.5]
y=[0,1.38629436,1.79175947,1.60943791,1.09861229,0.40546511,0.91629073,1.25276297]
def Lagrng(x,y,n,xx):
    sum=0
    for i in range(n):
        product=y[i]
        for j in range(n):
            if i != j:
                product=product*(xx-x[j])/(x[i]-x[j])
        sum=sum+product
    return sum

if __name__ == '__main__':
    LG=Lagrng(x,y,6,2)
    print(LG)