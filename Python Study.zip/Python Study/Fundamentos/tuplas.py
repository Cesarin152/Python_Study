#Tupla mantiene el orden ,pero ya no se puede modificar
#Lista mantiene el orden ,pero se puede modificar
frutas=("Naranja","Platano","Guayaba")#una tupla tiene redondos, la lista tiene corchete
#largo de la tupla
print(len(frutas))
#accddiendo a un elemento
print(frutas[2])
#navegacion inversa
print(frutas[-1])
#rango
print(frutas[0:2])#excluyendo el indice 2
#Intentar modificar
#frutas.append("Mango")
#frutas[0]="Naranjita"
frutasLista=list(frutas)#transformo la tupla frutas en una lista
frutasLista[1]="Platanito"#modifico la pos 1 y cambio por platanito
frutas=tuple(frutasLista)
print(frutas)
#iterar una tupla
for fruta in frutas:
    print(fruta,end=" ")
#no podemos agregar ni eliminar elementos de una tupla
#frutas.remove("naranja")
del frutas #eliminar variable fruta
#print(frutas)