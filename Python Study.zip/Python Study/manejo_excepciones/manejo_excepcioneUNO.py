
#a=10
#b=0
#result=None
#try:
#    result = a/b
#except Exception as e:
#    print("Ocurrio un error",e)
#    print(type(e))

#print("Resultado ",result)
#print("continuamos...")
#a="10"

from numeros_identicos_ex import NumerosIdenticosException


result=None
try:
    #a=input("Primer numero ")
    #b=input("Segundo numero")
    a=int(input("Primer numero "))
    b=int(input("Seguno numero "))
    if a==b:
        raise NumerosIdenticosException("Numeros identico error")
    result = a/b
#except ZeroDivisionError as e:
except  ZeroDivisionError as e:
    print("Ocurrio un error Zero divion ",e)
    print(type(e))
except TypeError as e:
    print("Ocurrio un error Type error ",e)
    print(type(e))
except Exception as e:
    print("Ocurrio un error Exception ",e)
    print(type(e))
else:
    print("No hay excepcion ")
finally:
    print("Fin del manejo de excepciones")
print("Resultado",result)
print("continuamos...2")
