from Sabrina import datos
from random import randint
class  GroupUniversity(object):
    def __init__(self,students,professor,college1,college2):
        self.students=students
        self.professor=professor
        self.college1=college1
        self.college2=college2
    def list_list(self):
        self.CStudents=[self.students,self.college1]
    def match(self):
        pass
    def check_math(self):
        pass
    




gp=GroupUniversity(datos.Students,datos.professor,datos.College_c,datos.College_c2)