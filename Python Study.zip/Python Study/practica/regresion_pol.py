#Importamos Librerias
import os
import statistics
import numpy as np
from math import sqrt
from matplotlib import pyplot as plt
#Variables globales
n=int(input('Ingrese la cantidad de datos:'))
x=list()
y=list()


def input_data()->None:
    #Pedimos data al usuario
    global y,x
    #Obteniendo Valores de X
    for i in range(n):
        os.system('cls')
        print('Ingrese el dato x'+str(i))
        x.append(float(input('')))
    #Obteniendo Valores de Y
    for i in range(n):
        os.system('cls')
        print('Ingrese el dato y'+str(i))
        y.append(float(input('')))

def sumas()->float:
    #Suma del vector x 
    #Suma del vector y
    global x,y
    x_sum=sum(x)
    y_sum=sum(y)
    x_media=statistics.median(x)
    y_media=statistics.median(y)    
    return x_sum,y_sum,x_media,y_media

def sumas_potenciales(p)->float:
    #Suma de vectores elevado a la 'p' potencia
    global x,y
    x_potencia=list()
    y_potencia=list()
    for i in range(len(x)):
        x_potencia.append(pow(x[i],p))
    for i in range(len(x)):
        y_potencia.append(pow(y[i],p))
    return sum(x_potencia),sum(y_potencia)

def sumas_prod(potencia_1,potencia_2)->float:
    #Suma de producto de vectores 
    global x,y
    product_sum=list()
    for i in range(len(x)):
        product_sum.append(pow(x[i],potencia_1)*pow(y[i],potencia_2))
    return sum(product_sum)

def gauss_simple(a,b,n=3)->list:
    #Gaus Simple Procedimiento eliminacion hacia adelante
    for k in range(n-1):
        for i in range(k+1,n):
            factor=a[i][k]/a[k][k]#Asigandole valores a factor de acuerdo al pivoteo de la diagonal principal
            for j in range(k,n):
            #Operaciones con filas de acuerdo el pivote o factor
                a[i][j]=a[i][j]-factor*a[k][j]
            b[i]=b[i]-factor*b[k]
    return a,b

def sustitucion_atras(a,b,n=3)->list:
    #Sustitucion hacia atras
    x=list(np.zeros((n,1)))
    #asignar el valor de x3
    x[n-1]=b[n-1]/a[n-1][n-1]
    #Despejando incognitas 'Encontrar x1,x2,xn...'
    for i in range(n-2,-1,-1):
        sum=0
        for j in range(i+1,n):
            sum=sum+a[i][j]*x[j]
        x[i]=(b[i]-sum)/a[i][i]
    return x

def a_b()->list:
    #Ajustando la Matriz a y el vector b
    x_sum,y_sum,x_media,y_media=sumas()
    x_2,y_2=sumas_potenciales(2)
    x_3,y_3=sumas_potenciales(3)
    x_4,y_4=sumas_potenciales(4)
    xy=sumas_prod(1,1)
    x2y1=sumas_prod(2,1)
    a=[[n,x_sum,x_2],
        [x_sum,x_2,x_3],
        [x_2,x_3,x_4]
    ]
    b=[y_sum,xy,x2y1]
    return a,b

def operaciones()->None:
    #Realizando Instrucciones
    input_data()
    a,b=a_b()
    A,B=gauss_simple(a,b)
    d=sustitucion_atras(A,B)
    os.system('cls')
    suma_residuos=sum_res(d)
    cof=correlacion(suma_residuos)
    impresion(d,suma_residuos,cof)
    graficar(d)

def sum_res(d)->float():
    #Obteniendo suma de residuos
    global x,y
    f=list()
    for i in range(len(x)):
        x_2,y_2=sumas_potenciales(2)
        f.append((y[i]-d[0]-(d[1]*x[i])-(d[2]*pow(x[i],2)))**2)
    suma_residuos=sum(f)
    return suma_residuos

def impresion(d,suma_residuos,cof)->str():
    global n
    y='y='+str(d[0])+'+'+str(d[1])+'x'+str(d[2])+'x^2'
    e=sqrt(suma_residuos/(n-(2+1)))
    print(y)
    print('error;',e)
    print('Coeficiente de determinación',cof**2)
    print('Coeficiente de correlación:',cof)
    
def correlacion(suma_residuos)->float:
    global y
    dist_Pmed=list()
    x,t,r,y_med=sumas()
    for i in range(len(y)):
        dist_Pmed.append(pow((y[i]-y_med),2))
    dist_sum=sum(dist_Pmed)
    cof=sqrt((dist_sum-suma_residuos)/dist_sum)
    return cof

def graficar(d)->None:
    global x,y
    plt.plot(x,y,'o',c='RED',label='Puntos')
    plt.plot(x,[f(i,d) for i in x],label='Polinomio')
    plt.legend()
    plt.title('Parabola de mínimos cuadrados')
    plt.ylabel('y')
    plt.xlabel('x')
    plt.show()

def f(x,d)->float:
    return d[0]+d[1]*x+(d[2]*(x**2))


if __name__ =='__main__':
    operaciones()


