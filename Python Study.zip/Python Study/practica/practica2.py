#Crea un programa que pida un número al usuario un número de mes (por ejemplo, el 4)
# y diga cuántos días tiene (por ejemplo, 30) y el nombre del mes. 
# Debes usar listas. Para simplificarlo vamos a suponer que febrero tiene 28 días.
#Meses de 30 días:
#Abril, junio, septiembre y noviembre.

#Meses de 31 días:
#Enero, marzo, mayo, julio, agosto, octubre y diciembre.
lista2=["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto","septiembre","Octubre","Noviembre","Diciembre"]
m=int(input("ingrese numero de mes por pantalla: "))
if m==1 or m==3 or m==5 or m==7 or m== 8 or m==10 or m==12:
    print("el mes tiene 31 dias")
elif m==2:
    print("el mes tiene 28 dias")
else:
    print("el mes tiene 30 dias")
print(lista2[m-1])
