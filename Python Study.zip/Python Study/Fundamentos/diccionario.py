#Un diccionario esta compuesto de llave,valor(key,value)
diccionario={
    "IDE":"Integrated Development Environmet",
    "OOP":"Objetc Oriented Programming",
    "DBMS":"Database Management System"
}
x="IDE" in diccionario
print(x)
print(diccionario)
#laro
print(len(diccionario))
#accediendo a un elemento
print(diccionario["IDE"])
#Otra forma
print(diccionario.get("IDE"))
#modificando valores
diccionario["IDE"] = "Integrated development environmet"
print(diccionario)
#iterar
for termino in  diccionario:
    print(termino)

for termino in diccionario:
    print(diccionario[termino])
for valor in diccionario.values():
    print(valor)
#comobando existencia de un elemento
D="IDE" in diccionario
print(D)
#agregar nuevos elementos
diccionario["PK"]="Primary Key"
print(diccionario)
#remover elementos
diccionario.pop("DBMS")
print(diccionario)
#limpiar
diccionario.clear()
print(diccionario)
#eliminar por completo
del diccionario
