import time
n=input('Ingrese un numero ')
m=int(input("1)Decimal a Binario\n2)Binario a decimal\n esperando:"))

arr=[1]#Declarar un arreglo

#Numero a binario
if(m == 1):
	binNumber=0
	#Transformando n a entero
	n=int(n)
	
	while True:
		i=max(arr)
		if(n>max(arr)):
			arr.append(i*2)
		else:
			arr.sort(reverse=True)
			print(arr)
			break
	for j in arr:#for each 
		binNumber=n//j
		print(str(binNumber),end="")
		n=n%j
elif (m == 2):
	myNum=0
	bin=[int(x) for x in str(n)]#1--->1:Entero 0---->2:entero
	bin2=list()
	g=0#contador
	bandera=False
	for g in range(len(bin)):#00000000000010
		
		if(bin[g] == 1 or bandera == True):
			bandera=True
			bin2.append(bin[g])
	bin2.insert(0,0)#0
	for k in range(len(bin2)):
		i=max(arr)
		arr.append(i*2)
		arr.sort()
	bin2.reverse()
	for y in range(len(bin2)):
		if(bin2[y]==1):
			myNum=myNum+arr[y]
	print(myNum)


		
			
	

