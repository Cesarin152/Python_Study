--SELECT * FROM persona WHERE id_persona in(1,2)
--INSERT INTO persona(nombre,apellido,email) VALUES('Susana','Lara','slara@mail.com')
SELECT * FROM persona
--UPDATE persona SET nombre='Ivonne',email='iesparza@mail.com' WHERE id_persona=3
--DELETE FROM persona WHERE id_persona=3
