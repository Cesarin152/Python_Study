# + es un ejemplo de sobrecarga
a=2
b=3
print(a+b)
st1="Hola "
st2="Mundo"
print(st1+st2)

lis1=[1,2]
lis2=[4,5]
print(lis1+lis2)