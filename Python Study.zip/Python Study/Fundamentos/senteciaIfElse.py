condicion=True
if(condicion==True):
    print("LA condicion es Verdadera")
elif condicion==False: #else if   
    print("La condicion es Falsa")
else:
    print("La condicion no reconocida")
    
numero=int(input("Ingrese un numero: "))
if numero==1:
    numeroTexto="Numero 1"
elif numero==2:
    numeroTexto="Numero 2"
elif numero==3:
    numeroTexto="Numero 3"
else:
    numeroTexto="Fuera Rango"
print("Numero proporcionado "+numeroTexto)
