import psycopg2 as db

conexion=db.connect(
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432",
    database="test_db"
)
try:
    with conexion:
        #Cursos es un objeto que nos va a permitir ejecutar secuencia SQL en pg
        with conexion.cursor() as cursor:
            sentencia='DELETE FROM persona WHERE id_persona IN %s'
            entrada=input("Proporciona los id_persona a eliminar(separados por coma): ")
            valores=(tuple(entrada.split(",")),)
            cursor.execute(sentencia,valores)#ejecutar registro en una sentencia o peticion
            #Guardar la informacion
            conexion.commit()
            registros_eliminados=cursor.rowcount
            print(f"Registros Eliminados: {registros_eliminados}")
except Exception as e:
    print(f'Ocurrio un error;{e}')
finally:
    conexion.close()  