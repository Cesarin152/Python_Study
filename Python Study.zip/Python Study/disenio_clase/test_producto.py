from producto import Producto

producto1=Producto("Camisa",100.00)
print(producto1)

producto2=Producto("Pantalon",110.00)
print(producto2)

#print(producto1.__str__())

#p=producto1
#print(p.__str__())
#f=p
#print(f.__str__())