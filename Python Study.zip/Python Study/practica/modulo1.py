class Multiplicacion:
    def __init__(self,a,b) -> None:
        self.a=a
        self.b=b
    def multiplicacion(self):
        return self.a*self.b
    
    
