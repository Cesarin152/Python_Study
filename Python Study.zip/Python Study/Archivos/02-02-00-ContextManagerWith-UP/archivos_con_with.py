from ManejoArchivos import ManejoArchivos

# with open('prueba.txt','r', encoding='utf8') as archivo:
with ManejoArchivos(r'C:\Users\Cesar\OneDrive\Programacion\pythondoc\Archivos\02-02-00-ContextManagerWith-UP\prueba.txt') as archivo:
    print(archivo.read())
