import random as r

b=list()
while(True):
    a=['Cesar','Victor','Gilberto','Macs','Edwin','Didier','Harmi']
    c=input('Esperando entrada A o B, E para salir:')
    c=c.upper()
    if c=='A':
        a.clear()
        x=int(input('Ingrese la cantidad de integrantes:'))
        #Agregando Nombres
        for i in range(x):
            print('Nombre #'+str(i+1))
            name=input()
            a.append(name)
        ####
        print('Resultados:')
        num=0
        while(True):
            
            if len(a)!=0:
                n=r.randint(0,len(a)-1)
                print(str(num)+'-'+a[n])
                a.pop(n)
                num+=1
                        
            else:
                break
    elif c=='B':
        print('Resultados:')
        num=0
        while(True):
            
            if len(a)!=0:
                n=r.randint(0,len(a)-1)
                print(str(num)+'-'+a[n])
                a.pop(n)
                num+=1
                        
            else:
                break
    elif c=='E':
        break
    else:
        print('Entrada incorrecta tonto')

