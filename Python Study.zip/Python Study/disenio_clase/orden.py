
class Orden:
    contador_ordenes=0
    def __init__(self,productos):
        Orden.contador_ordenes +=1
        self.__id_orden=Orden.contador_ordenes
        self.__productos=productos
    def agregar_producto(self,producto_nuevo):
        self.__productos.append(producto_nuevo)
    def get_id_orden(self):
        return self.__id_orden
    def set_id_orden(self,id_orden):
        self.__id_orden=id_orden
    def get_productos(self):
        return self.__producto
    def total_producto(self):
        total=0
        for producto in self.__productos:
            total+=producto.precio
        return total
    def  __str__(self):
        productos_str=""
        for producto in self.__productos:
            productos_str =productos_str + producto.__str__()+" -- "
        return "Orden: "+ str(self.__id_orden)+" Productos: "+productos_str +"precio total "+str(self.total_producto())
#def total_producto2(self):
#totals=0
#productoz=self.__productos
#while productoz in self.__productos:
#totals+=productoz.get_precio()
#return totals

