def imprimir(x):
    
    if x>0:
        imprimir(x-1)
        print(x)
        
n=int(input("ingrese un numero : "))
imprimir(n)
