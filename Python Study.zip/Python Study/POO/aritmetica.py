class Aritmetica:
    """Clase Aritmetica para realizar las operaciones de sumar,restar,etc"""
    def __init__(self,operando1,operando2):
        self.operando1=operando1
        self.operando2=operando2
    def sumar(self):
        """Se raliza la operacion con los atributos dela clase"""
        return self.operando1 + self.operando2
    def resta(self):
        """Se Realiza la resta con los atributos de la clase"""
        return self.operando1 - self.operando2
    def multiplicacion(self):
        """Se realiza la multiplicacion con los atributos de la clase"""
        return self.operando1 * self.operando2
    def division(self):
        """Se realiza la division con los atributos de la clase"""
        return self.operando1 / self.operando2
    def modulo(self):
        """Se realiza el modulo con los atributos de la clase"""
        return self.operando1 % self.operando2

######Creando un objeto######
aritmetica=Aritmetica(2,4)
print("Resultado de la suma: ",aritmetica.sumar())
#print("Operando  1:",aritmetica.operando1)
#Resta
aritmetica=Aritmetica(8,4)
print("El resultado de la resta: ",aritmetica.resta())
#multiplicacion
aritmetica3=Aritmetica(5,2)
print("El Resultado de la multiplicacion es: ",aritmetica3.multiplicacion())
#Division
aritmetica4=Aritmetica(6,2)
print("El resultado de la division: ",aritmetica4.division())
#modulo
aritmetica5=Aritmetica(2,2)
print("El resultado del modulo:",aritmetica5.modulo())