import time
import machine

led=machine.Pin(16,machine.Pin.OUT)
while True:
    led.on()
    time.sleep(1.5)
    led.off()
    time.sleep(1.5)