class Persona:
    def __init__(self,nombre,ape_paterno,ape_materno):
        self.nombre=nombre#Publico
        self._apellido_paterno=ape_paterno#Protegido
        self.__apellido_materno=ape_materno#Privado
    def metodo_publico(self):
        self.__metodo_privado()
    def __metodo_privado(self):
        print(self.nombre)
        print(self._apellido_paterno)
        print(self.__apellido_materno)
    @property
    def apellido_materno(self):
        return self.__apellido_materno
    @apellido_materno.setter
    def apellido_materno(self,ape_materno):
        self.__apellido_materno=ape_materno

p1=Persona("Juan","Lopez","Perez")
#p1.__metodo_privado()#Marca error
p1.metodo_publico() 
print(p1.nombre)
print(p1._apellido_paterno)
print(p1.apellido_materno)
#print(p1.__apellido_materno)Manda error
p1.apellido_materno="Garcia"
print(p1.apellido_materno)