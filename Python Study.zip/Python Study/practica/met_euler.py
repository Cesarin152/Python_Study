from matplotlib import pyplot as plt
import numpy as np

y_euler=[1.00000,5.25000,5.87500,5.12500,4.50000,4.75000,5.87500,7.12500,7.00000]
x=list()
for i in np.arange(0,4.5,0.5):
    x.append(i)
def f(x):
    return -0.5*(x**4)+4*(x**3)-10*(x**2)+8.5*(x)+1



plt.plot(x,y_euler,c='RED')
plt.plot(x,[f(i) for i in x])
plt.show()