def swap_case(s):
    swap_words=str()
    for i in s:
        if i.isupper():
            swap_words+=i.lower()
        else:
            swap_words+=i.upper()
    return swap_words

if __name__ == '__main__':
    s = input()
    result = swap_case(s)
    print(result)