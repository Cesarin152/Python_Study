class Papa:
    def juego_tenis():
        print("Juego Tenis")
class Mama():
    def como_mucho(self):
        print("Como pizza")

class hijo(Mama,Papa):
    def jugar_play():
        print("Juego Play")

hijo1=hijo()
mama=Mama()
print(isinstance(mama,Mama))