def suma(a,b):
    return a+b
print("La Suma es: ",suma(5,3));