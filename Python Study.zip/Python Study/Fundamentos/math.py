import math
from decimal import *
#"Floor"toma un número como parámetro y devuelve el mayor entero igual o menor que el número pasado como parámetro.
a = math.floor(4.3)
b = math.floor(10.9)
print(a)
print(b)
# "Ceil"toma un número como parámetro y devuelve el número entero más pequeño igual o mayor que el número pasado como parámetro.
c = math.ceil(4.3)
d = math.ceil(10.9)
print(c)
print(d)
#"fabs" toma un parámetro y devuelve su valor absoluto. 
e = math.fabs(10)
f = math.fabs(-10)
print(e)
print(f)
#"log"
# Cuando se pasa un parámetro, devuelve el logaritmo natural de ese número.
# Cuando se pasan dos parámetros, devuelve el logaritmo del primer número a la base del segundo número.
g = math.log(10)
h = math.log(10, 2)
print(g)
print(h)
#"sqrt"Devuelve la raiz cuadrada
i = math.sqrt(9)
j = math.sqrt(16)
print(i)
print(j)
#"pow"devuleve el numero elevado a la n donde n 
# es el exponente y a es el numero (a,n)
k=math.pow(4, 3)
print(k)
#Funciones trigonometricas
x=1
print(math.acos(x))
print(math.asin(x))
print(math.atan(x))
print(math.cos(x))
print(math.sin(x))
print(math.tan(x))
#Angulos
x =(math.pi)
print(math.degrees(x))
x=180
print(math.radians(x))
#Exponencial
print(math.exp(x))
#Constane
print(math.pi)
print(math.e)
print(math.inf)
print(-math.inf)
#factorial
print(math.factorial(5))
print(math.perm(8,3))









getcontext().prec = 100

def nilakantha(reps):
        result = Decimal(3.0)
        op = 1
        n = 2
        for n in range(2, 2*reps+1, 2):
                result += 4/Decimal(n*(n+1)*(n+2)*op)
                op *= -1
        return result

print("How many repetitions?")
repetitions = int(input())
print(nilakantha(repetitions))
#print("3.1415926535897932384626433832795028841971693993751058209749445923078164062862089986280348253421170679")