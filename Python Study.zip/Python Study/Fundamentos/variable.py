x=5
y=3
z=x+y
print(x)
print(y)
print(z)
w=z
print(w)
