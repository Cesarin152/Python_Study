import math
import time as t
#from decimal import *


def exponencial():#potenciales
    b=float(input("Ingrese la potencia a la que quiera elevar"))
    print("el resultado de esta exponencial es: ",math.exp(b))
def rag(): #transformar de radianes a grados
    rad=float(input("Ingrese los radianes: "))
    grad=rad*(180/math.pi)
    
def logaritmicas(): #Resuelve logaritmos
    a=float(input("Ingrese el numero"))
    if a==0:
        print("No se puede")
    else: 
        base=input("ingrese la base del logaritmo:")
        if base=="e":
            h=math.log(a)
        elif float(base)>0:
            h=math.log(a, float(base))
        else:
            print("Log error")
    print(h)

def raiz():  #sqrt"Devuelve la raiz cuadrada
    w=float(input("ingrese el numero a sacar la raiz"))
    i = math.sqrt(w)
    print("la raiz es:",i)
#Funciones trigonometricas
def trigonometricas():
    print("Ingrese la funcion trigonometrica que desea: ")
    print("[1] para seno")
    print("[2] para coseno")
    print("[3] para tangente ")
    print("[4] para arcoseno ")
    print("[5] para arcocoseno ")
    print("[6] para arcotangente ")
    patata2=int(input())
    if patata2==1:
        patata=input("Ingrese la porqueria de angulo ")
        print(math.sin(float(patata)))
    elif patata2==2:
        patata=input("Ingrese la porqueria de angulo ")
        print(math.cos(float(patata)))
    elif patata2==3:
        patata=input("Ingrese la porqueria de angulo ")
        print(math.tan(float(patata)))
    elif patata2==4:
        patata=input("Ingrese la porqueria de angulo ")
        print(math.asin(float(patata)))
    elif patata2==5:
        patata=input("Ingrese la porqueria de angulo ")
        print(math.acos(float(patata)))
    elif patata2==6:
        patata = input("Ingrese la porqueria de angulo ")
        print(math.atan(float(patata)))
    else:
        print("ponga una funcion válida")
#Funciones Aritmeticas 
def aritmeticas():
    print("[1]Suma")
    print("[2]Resta")
    print("[3]Division")
    print("[4]Multiplicacion")
    opt1=int(input("Ingrese el Numero"))
    if opt1 == 1:
        x = int(input("Ingrese el primer Valor"))
        y = int(input("Ingrese el segundo valor Valor"))
        tot=lambda x,y:x+y
        print(tot(x, y))
    if opt1 == 2:
        x = int(input("Ingrese el primer Valor"))
        y = int(input("Ingrese el segundo valor Valor"))
        tot=lambda x,y:x-y
        print(tot(x,y))
    if opt1 == 3:
        x = int(input("Ingrese el primer Valor"))
        y = int(input("Ingrese el segundo valor Valor"))
        tot=lambda x,y:x/y
        print(tot(x, y))
    if opt1 == 4:
        x = int(input("Ingrese el primer Valor"))
        y = int(input("Ingrese el segundo valor Valor"))
        tot=lambda x,y:x*y
        print(tot(x,y))   
    
    
    


while True:         
    try:
        print("Ingrese la opcion que desee: ")
        print("[1] para calcular logaritmos")
        print("[2] para transformar de radianes a grados")
        print("[3] para exponencial ")
        print("[4] para Raiz")
        print("[5] para trigonometricas")
        print("[6] para calculos basicos")
        opt=int(input())   
        
        if opt == 1: #logaritmicas
            logaritmicas()
            t.sleep(2)
            print("")
        elif opt == 2: #Rad a grados
            rag()
            t.sleep(2)
            print("")
        elif opt == 3: #Exponencial
            exponencial()
            t.sleep(2)
            print("")
        elif opt == 4: #Raiz
            raiz()
            t.sleep(2)
            print("")
        elif opt == 5: #trigonometricas
            trigonometricas()    
            t.sleep(2)
            print("")
        
        elif opt == 6: #Aritmeticas
            aritmeticas()
            t.sleep(2)
            print("")
    except:
        print("Syntax ERROR\n\n\n")
        t.sleep(2).
        continue
