"""class Persona:
    def __init__(self,n,e):
        self.__nombre=n
        self.__edad=e
    def get_nombre(self):#leyendo valor indirectamente
        return self.__nombre
    def set_nombre(self,nombre):#Modificando valor indirectamente privado
        self.__nombre=nombre
    def get_edad(self):
        return self.__edad
    def set_edad(self,edad):
        self.__edad=edad"""
class Persona:
    def __init__(self,n,e):
        self.__nombre=n
        self.__edad=e
    @property#Es igual a get_
    def nombre(self):#leyendo valor indirectamente
        return self.__nombre
    @nombre.setter
    def nombre(self,nombre):#Modificando valor indirectamente privado
        self.__nombre=nombre
    @property
    def edad(self):
        return self.__edad
    @edad.setter
    def edad(self,edad):
        self.__edad=edad

p1=Persona("Juan",18)
#print(p1.__nombre)#Marca un error ya que es privado
print(p1.nombre)
print(p1.edad)
#p1.__nombre="Karla" #Marca error ya que es privado
p1.nombre="Karla"
print(p1.nombre)
#imprimir valor nuevo(edad)
#print(p1.__edad) Marca error ya que es privado
p1.edad=20
print(p1.edad)
