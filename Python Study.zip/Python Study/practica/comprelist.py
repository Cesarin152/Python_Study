import itertools as it
lista=list()

def full_Arr(x,y,z,n):
    for i in range(1,n+1):
        lista.append()

def arr(x,y,z):
    
def check():





if __name__ == '__main__':
    x = int(input())
    y = int(input())
    z = int(input())
    n = int(input())
    
    

