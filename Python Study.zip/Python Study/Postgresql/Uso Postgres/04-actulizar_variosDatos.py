import psycopg2 as db

conexion = db.connect(
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432",
    database="test_db"
)
try:
    with conexion:
        #Cursos es un objeto que nos va a permitir ejecutar secuencia SQL en pg
        with conexion.cursor() as cursor:
            sentencia = 'UPDATE persona SET nombre=%s,apellido=%s,email=%s WHERE id_persona=%s'
            valores =(
                ("Kim","Lee","klee@mail.com",2),
                ("Khadin","Magallon","kmagallon@mail.com",4)
            )
            # ejecutar registro en una sentencia o peticion
            cursor.executemany(sentencia, valores)
            # Guardar la informacion
            #conexion.commit()
            registros_actualizados = cursor.rowcount
            print(f"Registros Actualizados: {registros_actualizados}")
except Exception as e:
    print(f'Ocurrio un error;{e}')
finally:
    conexion.close()  
