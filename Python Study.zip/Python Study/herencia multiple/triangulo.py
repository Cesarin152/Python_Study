from figura_geometrica import FiguraGeometrica
from color import Color
class Triangulo(FiguraGeometrica,Color):
    def __init__(self,base,altura,color):
        FiguraGeometrica.__init__(self,base,altura)
        Color.__init__(self,color)
    def area(self):
        return str((1/2)*self.alto*self.ancho)
    def __str__(self):
        return super().__str__()+" Color: "+ Color.__str__(self)+" Area total:"