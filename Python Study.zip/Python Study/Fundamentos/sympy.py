from sympy import Symbol

x = Symbol('x')
y = Symbol('y')
2 * x - x



