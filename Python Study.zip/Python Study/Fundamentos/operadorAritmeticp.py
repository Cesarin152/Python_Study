a=3
b=2
suma=a+b
print("El resultado es",suma)
resta=a-b
print("La resta es",resta)
multi=a*b
print("La multiplicacion es",multi)
div=a/b
print("La division es",div)
modulo=a%b
print("El modulo es",modulo)
exp=a**b
print("El resultado es ",exp)