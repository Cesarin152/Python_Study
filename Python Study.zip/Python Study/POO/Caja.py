class Caja:
    def __init__(self,alto,ancho,largo):
        self.alto=alto
        self.ancho=ancho
        self.largo=largo
    def calcula_volumen(self):
        return self.alto * self.ancho * self.largo

alto=int(input("Ingrese el alto "))
largo=int(input("Ingrese el largo "))
ancho=int(input("Ingrese el ancho "))

Volumen=Caja(alto,ancho,largo)
print("El Volumen es",Volumen.calcula_volumen())