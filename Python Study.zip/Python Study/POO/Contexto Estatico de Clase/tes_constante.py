from constante import MI_CONSTANTE
from constante import Matematicas as mate
print(MI_CONSTANTE)
print(mate.PI)


MI_CONSTANTE="Valor NUEVO"
mate.PI=3.14
print(MI_CONSTANTE)
print(mate.PI)
