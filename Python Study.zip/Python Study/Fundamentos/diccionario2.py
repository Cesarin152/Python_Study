
diccionario={}
diccionario["manzana"]=2
diccionario["pera"]=1
diccionario["uva"]=5
d=1
k=3
for d in range(k):
    a=input("ingrese la fruta que desea: ")
    c=input("ingrese la cantidad de esa fruta que desea: ")
    print("el precio total de esa fruta es: ",diccionario[a]*c)
    j=input("desea consultar otra fruta? [1] si; [2] no: ")
    if j==2:
        print("gracias, vuelva pronto")
        d=4
    else:d=1

