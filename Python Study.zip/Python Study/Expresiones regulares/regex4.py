import re

lista_nombre=['Ana',
            'Pedro',
            'Rosa',
            'Sandra',
            'Celia']

for elemento in lista_nombre:
    if re.findall('^[O-T]',elemento):
        print(elemento)
for elemento in lista_nombre:
    if re.findall('[o-t]$',elemento):
        print(elemento)

lista_ciudad=['Ma1',
            'Se1',
            'Ma2',
            'Ba1',
            'Ma3',
            'Va.1',
            'Va:2',
            'Ma4',
            'MaA',
            'Ma5',
            'MaB',
            'MaC']
print()
for ciudad in lista_ciudad:
    if re.findall('Ma[0-3]',ciudad):
        
        print(ciudad)
print()
for ciudad in lista_ciudad:
    if re.findall('Ma[^0-3]',ciudad):#Nos devuelve aquel que no cumpla el rango si se coloca el metacaracter antes del rango Negacion
        
        print(ciudad)
print()
for ciudad in lista_ciudad:
    if re.findall('Ma[0-3A-B]',ciudad):
        
        print(ciudad)
print()
for ciudad in lista_ciudad:
    if re.findall('Va[.:]',ciudad):
        
        print(ciudad)