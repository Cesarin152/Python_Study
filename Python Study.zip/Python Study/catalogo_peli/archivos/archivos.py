try:
    archivo=open("prueba.txt","w")
    archivo.write("Info\n")
    archivo.write("Adios")
except Exception:
    print(Exception)
finally:
    archivo.close()