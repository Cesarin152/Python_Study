#set es una colección sin orden y sin indice , no permite elementos repetidos
# y los elementos no se pueden modificar,pero si agregar nuevos o eliminar
planeta={"Marte","Jupiter","Venus"}
print(planeta)
#largo
print(len(planeta))
# Revisar si esta presente
print("Marte" in planeta)
#agregar
planeta.add("Tierra")
print(planeta)
planeta.add("Tierra")#no se pueden agregar elementos duplicado
print(planeta)
#eliminar con remove posiblemente arroja error
planeta.remove("Tierra")
print(planeta)
#eliminar con discard no arroja error
planeta.discard("Jupiter")
print(planeta)
#limpiar el set
planeta.clear()
print(planeta)
#eliminar set
del planeta
print(planeta)