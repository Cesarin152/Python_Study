MI_CONSTANTE="Valor de mi constante"
class Matematicas:
    PI=3.1416
#print(MI_CONSTANTE)
#print(Matematicas.PI)