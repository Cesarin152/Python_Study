string='.|.'
n,m=input().split(' ')
n=int(n)
m=n*3
st=string
for i in range(n//2):
    print(st.center(m,'-'))
    st+=string*2
print('WELCOME'.center(m,'-'))
for i in range(n//2):
    st=st[:-6]
    print(st.center(m,'-'))
