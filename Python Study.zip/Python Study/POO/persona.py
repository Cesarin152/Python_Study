class Persona:#Dentro de una clase hay 2 variables;variables de clase y de  instancia
    #Constructor( Variable Instancia)
    Variable_Clase=0
    def __init__(self,nombre,edad):
        self.nombre=nombre
        self.edad=edad
#Modificar Valores(no se usa)
Persona.nombre="Juan"
Persona.edad=28

#Acceder a los valores(no se usa)
print(Persona.nombre)
print(Persona.edad)

#Creacion de un objeto
persona = Persona("Karla",30)
print(persona.nombre)
print(persona.edad)
print(id(persona))

#Creacion de un segundo objeto
persona2=Persona("Carlos",40)
print(persona2.nombre)
print(persona2.edad)
print(id(persona2))
