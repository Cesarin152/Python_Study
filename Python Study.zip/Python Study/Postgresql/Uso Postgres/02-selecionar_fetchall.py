import psycopg2 as db

conexion=db.connect(
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432",
    database="test_db"
)
try:
    with conexion:
        #Cursos es un objeto que nos va a permitir ejecutar secuencia SQL en pg
        with conexion.cursor() as cursor:

            sentencia='SELECT * FROM persona WHERE id_persona IN %s'
            entrada=input("Proporciona las Pk a buscar(separado por comas): ")
            tupla=tuple(entrada.split(","))
            #llaves_primarias=((1,2,3),)
            llaves_primarias=(tupla,)
            cursor.execute(sentencia,llaves_primarias)
            registros=cursor.fetchall()
            for registro in registros:
                print(registro)
except Exception as e:
    print(f'Ocurrio un error;{e}')
finally:
    conexion.close()  