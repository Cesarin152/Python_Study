# -*- coding: utf-8 -*-
"""
Created on Sat Jan 22 18:19:04 2022

@author: cesar
"""

import numpy as np
#Conocer dimensiones de una matriz
a=np.array([[1,2,3],[4,5,6]])
print(a.ndim)
print()
#Conocer el tipo de datos
print(a.dtype)
print()
#Conocer el tamanio y forma de la matriz
print(a.size)
print(a.shape)
print()
#Cambio de forma de una matriz
a=a.reshape(3,2)
print(a)
print()
#Extraer un solo valor
print(a[0,0])
print()
#Extraer los valores de todas las filas ubicados en la columna 2
print(a[0:,1])
print()
#Encontrar el minimo,maximo y la suma
print(a.min())
print(a.max())
print(a.sum())
print()
#Calcular Raiz cuadrada y la desviacion estandar
print(np.sqrt(a))
print(np.std(a))
x=np.array([(1,2,3),(3,4,5)])
y=np.array([(1,2,3),(3,4,5)])
print(x+y)
print(x-y)
print(x*y)
print(x/y)