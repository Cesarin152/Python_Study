import psycopg2 as db

conexion=db.connect(
    user="postgres",
    password="admin",
    host="127.0.0.1",
    port="5432",
    database="test_db"
)
try:
    with conexion:
        #Cursos es un objeto que nos va a permitir ejecutar secuencia SQL en pg
        with conexion.cursor() as cursor:
            sentencia="SELECT * FROM persona"
            #sentencia="SELECT * FROM persona ORDER BY id_persona"
            #sentencia="SELECT * FROM persona ORDER BY id_persona DESC"
            cursor.execute(sentencia)#Ejecutando sentencia
            registros=cursor.fetchall() #Recuperar los datos ejecutados por execute
            print(registros)
except Exception as e:
    print(f'Ocurrio un error;{e}')
finally:
    conexion.close()      
