import time
#sin usar Hilos
def worker_1(rango):
    lista =list()
    for i in range(rango):
        lista.append(i)
        time.sleep(0.01)
    return lista

t0=time.time()
print("Time 1",t0)
lista_1=worker_1(100)
tf=time.time()-t0
print("Tiempo total en 1 thread: {}\n".format(tf))
print(lista_1)

